# matchmaking.py
#Rodas Gebreyohannes
#july/26/2024
#

# Global constants for category weightings
ATHLETICISM_WEIGHT = 0.15
FOOD_OUT_WEIGHT = 0.10
ENTERTAINMENT_OUT_WEIGHT = 0.15
SERIOUS_RELATIONSHIP_WEIGHT = 0.20
RELIGION_WEIGHT = 0.20
POLITICS_WEIGHT = 0.20

def rate(rating1, rating2):
    """
    Returns the probability of a match between two ratings.
    """
    diff = abs(rating1 - rating2)
    if diff <= 1:
        return 1.0
    elif diff <= 3:
        return 0.7
    elif diff <= 6:
        return 0.4
    else:
        return 0.0

def match(person1, person2):
    """
    Returns the overall probability of a match between two people.
    """
    # Calculate probabilities for each category
    athleticism_prob = rate(person1[0], person2[0]) * ATHLETICISM_WEIGHT
    food_out_prob = rate(person1[1], person2[1]) * FOOD_OUT_WEIGHT
    entertainment_out_prob = rate(person1[2], person2[2]) * ENTERTAINMENT_OUT_WEIGHT
    serious_relationship_prob = rate(person1[3], person2[3]) * SERIOUS_RELATIONSHIP_WEIGHT
    
    # Special cases for religion and politics
    if person1[4] >= 8 or person2[4] >= 8:
        if person1[5] == person2[5]:
            religion_prob = 1.0 * RELIGION_WEIGHT
        else:
            religion_prob = 0.5 * RELIGION_WEIGHT
    else:
        religion_prob = rate(person1[4], person2[4]) * RELIGION_WEIGHT
    
    if person1[6] >= 9 or person2[6] >= 9:
        politics_prob = rate(person1[7], person2[7]) * POLITICS_WEIGHT
    else:
        politics_prob = rate(person1[6], person2[6]) * POLITICS_WEIGHT
    
    # Calculate overall probability
    overall_prob = athleticism_prob + food_out_prob + entertainment_out_prob + serious_relationship_prob + religion_prob + politics_prob
    
    return overall_prob

def main():
    # Create two person tuples
    person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
    person2 = (4, 5, 6, 10, 8, "judaism", 3, 2)
    
    # Calculate and display the probability of a match
    prob = match(person1, person2)
    print(f"The probability of a compatible match is {prob*100:g}%")

if __name__ == "__main__":
    main()