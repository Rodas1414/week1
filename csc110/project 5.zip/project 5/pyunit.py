# TestMatchmaker.py

import unittest
from  import rate, match, ATHLETICISM_WEIGHT, FOOD_OUT_WEIGHT, ENTERTAINMENT_OUT_WEIGHT, SERIOUS_RELATIONSHIP_WEIGHT, RELIGION_WEIGHT, POLITICS_WEIGHT

class TestMatchmaker(unittest.TestCase):

### Rate Function Tests ###

    def test_rate_diff_0(self):
        """Test rate function with difference of 0"""
        self.assertEqual(rate(5, 5), 1.0)

    def test_rate_diff_1(self):
        """Test rate function with difference of 1"""
        self.assertEqual(rate(5, 6), 1.0)

    def test_rate_diff_3(self):
        """Test rate function with difference of 3"""
        self.assertEqual(rate(5, 8), 0.7)

    def test_rate_diff_6(self):
        """Test rate function with difference of 6"""
        self.assertEqual(rate(5, 11), 0.4)

    def test_rate_diff_large(self):
        """Test rate function with large difference"""
        self.assertEqual(rate(5, 20), 0.0)

### Match Function Tests ###

    def test_match_athleticism(self):
        """Test match function with athleticism category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (7, 5, 6, 10, 8, "judaism", 3, 2)
        self.assertAlmostEqual(match(person1, person2), ATHLETICISM_WEIGHT, places=2)

    def test_match_food_out(self):
        """Test match function with food out category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 10, 6, 10, 8, "judaism", 3, 2)
        self.assertAlmostEqual(match(person1, person2), FOOD_OUT_WEIGHT, places=2)

    def test_match_entertainment_out(self):
        """Test match function with entertainment out category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 5, 8, 10, 8, "judaism", 3, 2)
        self.assertAlmostEqual(match(person1, person2), ENTERTAINMENT_OUT_WEIGHT, places=2)

    def test_match_serious_relationship(self):
        """Test match function with serious relationship category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 5, 6, 9, 8, "judaism", 3, 2)
        self.assertAlmostEqual(match(person1, person2), SERIOUS_RELATIONSHIP_WEIGHT, places=2)

    def test_match_religion(self):
        """Test match function with religion category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 5, 6, 10, 8, "buddhism", 3, 2)
        self.assertAlmostEqual(match(person1, person2), RELIGION_WEIGHT, places=2)

    def test_match_politics(self):
        """Test match function with politics category"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 5, 6, 10, 8, "judaism", 6, 8)
        self.assertAlmostEqual(match(person1, person2), POLITICS_WEIGHT, places=2)

    def test_match_all_categories(self):
        """Test match function with all categories"""
        person1 = (7, 10, 8, 9, 10, "buddhism", 6, 8)
        person2 = (4, 5, 6, 10, 8, "judaism", 3, 2)
        self.assertGreater(match(person1, person2), 0.0)
        self.assertLess(match(person1, person2), 1.0)

if __name__ == "__main__":
    unittest.main()