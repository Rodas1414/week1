#Rodas Gebreyohannes
#csc110 
#PROJECT 8

# Ask the user for input
river = input("Which river? ").strip()
month = int(input("Which month (e.g., 1 for January)? "))
pollutant = int(input("Available pollutants:\n1. Arsenic\n2. Lead\n3. Fertilizer\n4. Pesticides\nWhich pollutant? "))

# Initialize variables
count = 0
total = 0.0
minimum = float('inf')
maximum = float('-inf')

# Open the input file
with open("/Users/rodastesfay/Desktop/csc110/project 8/PollutionSummary.txt", "r") as f:
    for line in f:
        # Read the data from the file
        data = line.strip().split("\t")
        if data[0] == river and int(data[1][5:7]) == month and int(data[2]) == pollutant:
            count += 1
            total += float(data[3])
            if float(data[3]) < minimum:
                minimum = float(data[3])
            if float(data[3]) > maximum:
                maximum = float(data[3])

            # If we've processed 20 rows, break out of the loop
            if count == 20:
                break

# Open the output file
with open("/Users/rodastesfay/Desktop/csc110/project 8/RiverPollutionData.txt", "w") as f:
    # Write the header to the file
    f.write(f"Data for river: {river}\n")
    f.write(f"Data for month: {month}\n")
    f.write(f"Data for pollutant: {pollutant}\n")
    f.write(f"Number of readings: {count}\n")
with open("RiverPollutionData.txt", "w") as file:
    # Read the file and calculate the total and count
 with open("/Users/rodastesfay/Desktop/csc110/project 8/PollutionSummary.txt", "w") as f:
    if count > 0:
        f.write(f"Average of readings: {total / count:.3f}\n")
    else:
     f.write("No readings to calculate average.\n") 
     f.write(f"Lowest reading: {minimum:.3f}\n")
     f.write(f"Highest reading: {maximum:.3f}\n")

print("Processing of 20 rows is complete. See summary file for results.")